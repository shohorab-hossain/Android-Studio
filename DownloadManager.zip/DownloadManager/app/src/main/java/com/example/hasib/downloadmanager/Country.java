package com.example.hasib.downloadmanager;

/**
 * Created by HASIB on 3/30/2018.
 */

public class Country {

    String code = null;
    String name = null;

    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }


}
