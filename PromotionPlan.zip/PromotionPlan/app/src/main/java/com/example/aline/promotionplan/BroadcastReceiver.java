package com.example.aline.promotionplan;

/**
 * Created by HASIB on 2/26/2018.
 */

class BroadcastReceiver {
}
